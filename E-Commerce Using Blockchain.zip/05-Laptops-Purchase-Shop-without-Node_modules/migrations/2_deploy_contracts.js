var laptopspurchase = artifacts.require("./laptopspurchase.sol");

module.exports = function(deployer) {
  deployer.deploy(laptopspurchase);
};
